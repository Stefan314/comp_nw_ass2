# Computer Networks Assignment 2
    Isabel Stein    Stefan Deelen
    isabel21@ru.is  stefand21@ru.is

    Open the terminal and type: make
    Wait untill all ports have been checked, it should then print out which are open.
